-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2022 at 06:08 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodorder`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(13, 'Chang Yu Qian', 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(14, 'Burger', 'Food_Category_337.png', 'Yes', 'Yes'),
(15, 'Salad', 'Food_Category_587.jpg', 'Yes', 'Yes'),
(17, 'Pizza', 'Food_Category_7.jpg', 'Yes', 'Yes'),
(18, 'Drinks', 'Food_Category_208.jpg', 'Yes', 'Yes'),
(22, 'Pasta', 'Food_Category_215.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`id`, `name`, `number`, `username`, `email`, `address`, `password`) VALUES
(1, 'Bernie See', '0123348282', 'bernie123', 'Bern123@gmail.com', ' 9Th Floor Merlin Tower Jln Meldrum', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'Customer 1', '0123348282', 'cus1', 'cus1@gmail.com', 'Level 34, Menara Telekom, Jalan Pantai Baru, 59200 Kuala Lumpur', '81dc9bdb52d04dc20036dbd8313ed055'),
(4, 'See Jun Yu', '0123567992', 'sjy123', 'sjy123@gmail.com', 'Level 10, 1 Sentral, Jalan Rakyat, Kuala Lumpur Sentral', '81dc9bdb52d04dc20036dbd8313ed055'),
(6, 'Peter Lee', '0102994174', 'Peter123', 'peter123@gmail.com', ' 11Th Floor Kishlan Tower Jln Jazz', '81dc9bdb52d04dc20036dbd8313ed055'),
(7, 'Peter Lee', '0102994174', 'Peter123', 'peter123@gmail.com', ' 11Th Floor Kishlan Tower Jln Jazz', '81dc9bdb52d04dc20036dbd8313ed055'),
(8, 'Alex Lim', '0134456677', 'alex123', 'alex321@yahoo.com', 'Level 15, 99 Sentral, Jalan Abu, Kuala Lumpur Sentral, 50706 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '81dc9bdb52d04dc20036dbd8313ed055'),
(9, 'Michie Lee', '0137889912', 'michie9912', 'michie9912@hotmail.com', '88,1 Sentral, Jalan Ahlo, Kuala Lumpur Sentral, 50706 Kuala Lumpur, Wilayah Persekutuan Kuala Lumpur', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(12, 'Lemon Swiss Chard Pasta', 'A quick and easy vegetarian weeknight pasta made with lemon, garlic, and Swiss chard. ', '19.50', 'Food-Name-7338.jpg', 22, 'Yes', 'Yes'),
(13, 'Creamy Pasta with Smoked Salmon', 'This smoked salmon pasta was smokin’…I’m loosing my noodle over it!', '19.00', 'Food-Name-1805.png', 22, 'Yes', 'Yes'),
(14, 'Spicy Korean Penne Pasta', 'As much as I love a big bowl of chili or some warm, comforting soup. .  nothing is more comforting to me than Korean food.', '25.00', 'Food-Name-3385.webp', 22, 'Yes', 'Yes'),
(15, 'Japanese Pasta with Shrimp and Asparagus', 'Spring is in the air! Say goodbye to hot pot and stews, and let’s welcome bright and light dishes with spring vegetables!', '25.00', 'Food-Name-7694.jpg', 22, 'Yes', 'Yes'),
(16, 'Spaghetti with Cherry Tomato Sauce', 'This dish is light and summery, definitely not like a spaghetti with marinara. It is a perfect way to use that bumper crop of cherry tomatoes! Add a little grated parmesan before serving.\r\n\r\n', '15.00', 'Food-Name-3764.jpg', 22, 'Yes', 'Yes'),
(17, 'Beef steak burger', 'Beef steak burger with caramelised onions and prickled cucumbers layed on barbecure sauce\r\n', '20.00', 'Food-Name-1059.jpg', 14, 'Yes', 'Yes'),
(18, 'All American Burger', 'This burger makes me feel uber American as if I’ve pulled up a stool at a classic American diner where food is served up fast and right off the griddle.', '25.00', 'Food-Name-5635.jpg', 14, 'Yes', 'Yes'),
(19, 'Omakase Burger', 'Omakase Burger offers cheeseburgers, chicken burgers, fries, beer and more.', '15.00', 'Food-Name-1315.webp', 14, 'Yes', 'Yes'),
(20, 'Moroccan Spiced Turkey Burgers', 'Burger with feta cheese, baby spinach and tomato in a whole-wheat bun. ', '28.00', 'Food-Name-9887.jpg', 14, 'Yes', 'Yes'),
(21, 'Bean Salad with Tomatoes and Feta', 'Crisp Bean Salad with Tomatoes and Feta, all tossed together in a simple vinaigrette!  This dish is the first one to go when I serve it at BBQ parties!', '25.00', 'Food-Name-2560.jpg', 15, 'Yes', 'Yes'),
(22, 'Massaged Kale Salad with Honey-Chipotle Vinaigrette', 'Full of big flavors and perfect for spring. We served this massaged kale salad next to a fresh piece of grilled salmon and it was sensational.', '19.00', 'Food-Name-8513.jpg', 15, 'Yes', 'Yes'),
(23, 'Spinach Salad', 'This spinach salad is an old family favorite; Even the salad haters in our family LOVE this', '10.00', 'Food-Name-9819.jpg', 15, 'Yes', 'Yes'),
(24, 'Jackfruit Taco Salad', 'This jackfruit taco salad is a yummy, easy weeknight meal.', '20.00', 'Food-Name-3131.jpg', 15, 'Yes', 'Yes'),
(25, 'Roasted Beet Salad', 'This stunning salad features roasted beets, creamy labneh, and a bright citrus ginger dressing. Topped with toasted walnuts, quick pickled shallots, and fresh dill', '20.00', 'Food-Name-3863.jpg', 15, 'Yes', 'Yes'),
(28, 'Pepperoni Pizza', 'This Pepperoni Pizza has everything you want—a great crust, gooey cheese, and tons of pepperoni.', '25.00', 'Food-Name-6916.jpg', 17, 'Yes', 'Yes'),
(29, 'Hawaiian pizza', 'Hawaiian pizza is the perfect combination of sweet and savory flavors loaded on top of a crispy crust.', '25.00', 'Food-Name-9433.jpg', 17, 'Yes', 'Yes'),
(30, 'Pizza Margherita', 'Here is the archetype of a thin-crust pizza pie, a pizza margherita adorned simply in the colors of the Italian flag: green from basil, white from mozzarella, red from tomato sauce. ', '24.00', 'Food-Name-8397.jpg', 17, 'Yes', 'Yes'),
(31, 'Ultimate Veggie Pizza', 'It’s fresh and full of flavor, featuring cherry tomatoes, artichoke, bell pepper, olives, red onion and some hidden (and optional) baby spinach.', '20.00', 'Food-Name-8208.jpg', 17, 'Yes', 'Yes'),
(32, 'Mineral Water', 'Mineral Water', '2.00', 'Food-Name-672.jpg', 18, 'Yes', 'Yes'),
(33, 'Coca Cola', 'Coca Cola', '5.00', 'Food-Name-3995.jpg', 18, 'Yes', 'Yes'),
(34, 'Ice Lemon Tea', 'Delicious vegan iced lemon tea recipe.', '7.00', 'Food-Name-4652.jpg', 18, 'Yes', 'Yes'),
(35, 'Green Tea', 'Hot Green tea', '3.00', 'Food-Name-5819.jpg', 18, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(12, 'Lemon Swiss Chard Pasta', '19.00', 1, '19.00', '2022-06-20 09:52:10', 'On Delivery', 'Bernie see', '018 2224502', 'xibernie@gmail.com', ' 9Th Floor Merlin Tower Jln Meldrum'),
(25, 'Lemon Swiss Chard Pasta', '19.00', 1, '19.00', '2022-07-03 04:46:02', 'Delivered', 'Customer 1', '0123348282', 'cus1@gmail.com', 'Level 34, Menara Telekom, Jalan Pantai Baru, 59200 Kuala Lumpur'),
(31, 'Pepperoni Pizza', '25.00', 2, '50.00', '2022-07-06 05:47:51', 'Delivered', 'Customer 1', '0123348282', 'cus1@gmail.com', 'Level 34, Menara Telekom, Jalan Pantai Baru, 59200 Kuala Lumpur');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
