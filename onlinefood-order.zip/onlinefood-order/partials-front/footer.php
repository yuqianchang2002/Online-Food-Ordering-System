<html>
<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                <li>
					<p>Contact No: 03-9011 4431</p>
					
                </li>
				<li>
					<p>Email: westfood@gamil.com</p>
				</li>
				<li>
					<P>Address: 44-46, Jalan Anggur, Bandar Sungai, Cheras, 432000 Selangor, Malaysia</P>
				</li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By Group 3 (Chang Yu Qian, Felix Hoi Man Yew, Alda Lim, Jerusha)</p>
        </div>			
	</section>
	</div>
    <!-- footer Section Ends Here -->

</body>
</html>
<!--code end-->
