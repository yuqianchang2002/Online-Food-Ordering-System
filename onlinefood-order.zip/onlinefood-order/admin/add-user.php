<?php include('partials/header.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Add User</h1>

        <br><br>

        <?php 
            if(isset($_SESSION['add'])) //Checking whether the SEssion is Set of Not
            {
                echo $_SESSION['add']; //Display the SEssion Message if SEt
                unset($_SESSION['add']); //Remove Session Message
            }
        ?>

        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Full Name: </td>
                    <td>
                        <input type="text" name="name" placeholder="Enter Your Name">
                    </td>
                </tr>

                <tr>
				<td>number: </td>
                    <td>
                        <input type="text" name="number" placeholder="Enter Your number">
                    </td>
                </tr>

                <tr>
                    <td>Username: </td>
                    <td>
                        <input type="text" name="username" placeholder="Your Username">
                    </td>
                </tr>
				<td>Email: </td>
                    <td>
                        <input type="text" name="Email" placeholder="Enter Your Email">
                    </td>
                </tr>

                <tr><td>Address: </td>
                    <td>
                        <input type="text" name="address" placeholder="Enter Your address">
                    </td>
                </tr>

                <tr>

                <tr>
                    <td>Password: </td>
                    <td>
                        <input type="password" name="password" placeholder="Your Password">
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="submit" value="Add User" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>


    </div>
</div>

<?php include('partials/footer.php'); ?>


<?php 
    if(isset($_POST['submit']))
    {
        //1. Get the Data from form
        $name = $_POST['name'];
		$number = $_POST['number'];
        $username = $_POST['username'];
		$email = $_POST['name'];
		$address = $_POST['address'];
		$password = md5($_POST['password']); //Password Encryption with MD5
         $sql=mysqli_query($conn,"insert into tbl_customer (name,number,username,email,address,password) values('$name','$number','$username','$email','$address','$password')");//insert data  into tbl_customer table

                   
        //2. SQL Query to Save the data into database
        $sql = "INSERT INTO tbl_customer SET 
            name='$name',
			number='$number',
			email='$email',
			address='$address',
            username='$username',
            password='$password'
        ";
 
        //4. Check whether the (Query is Executed) data is inserted or not and display appropriate message
        if($res==TRUE)
        {
            //Data Inserted
            //Create a Session Variable to Display Message
            $_SESSION['add'] = "<div class='success'>User Added Successfully.</div>";
            //Redirect Page to Manage User
            header("location:".SITEURL.'admin/manage-user.php');
        }
        else
        {
            //FAiled to Insert DAta
            //Create a Session Variable to Display Message
            $_SESSION['add'] = "<div class='error'>Failed to User.</div>";
            //Redirect Page to Add user
            header("location:".SITEURL.'admin/manage-user.php');
        }

    }
    
?>
<!--code end-->
