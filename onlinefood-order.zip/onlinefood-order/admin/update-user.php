<?php include('partials/header.php'); ?>

<div class="main-content">
    <div class="wrapper">
        <h1>Update User</h1>

        <br><br>

        <?php 
            //1. Get the ID of Selected User
            $id=$_GET['id'];

            //2. Create SQL Query to Get the Details
            $sql="SELECT * FROM tbl_customer WHERE id=$id";

            //Execute the Query
            $res=mysqli_query($conn, $sql);

            //Check whether the query is executed or not
            if($res==true)
            {
                // Check whether the data is available or not
                $count = mysqli_num_rows($res);
                //Check whether we have admin data or not
                if($count==1)
                {
                    // Get the Details
                    $row=mysqli_fetch_assoc($res);

                    $name = $row['name'];
                    $username = $row['username'];
					$address = $row['address'];
					$email = $row['email'];					
                }
                else
                {
                    //Redirect to Manage User Page
                    header('location:'.SITEURL.'admin/manage-user.php');
                }
            }
        
        ?>


        <form action="" method="POST">

            <table class="tbl-30">
                <tr>
                    <td>Full Name: </td>
                    <td>
                        <input type="text" name="name" value="<?php echo $name; ?>">
                    </td>
                </tr>

                <tr>
                    <td>Username: </td>
                    <td>
                        <input type="text" name="username" value="<?php echo $username; ?>">
                    </td>
                </tr>
				
				<td>Address: </td>
                    <td>
                        <input type="text" name="address" value="<?php echo $address; ?>">
                    </td>
                </tr>

				<td>Email: </td>
                    <td>
                        <input type="text" name="email" value="<?php echo $email; ?>">
                    </td>
                </tr>
				
                <tr>
                    <td colspan="3">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="submit" value="Update User" class="btn-secondary">
                    </td>
                </tr>

            </table>

        </form>
    </div>
</div>

<?php 

    //Check whether the Submit Button is Clicked or not
    if(isset($_POST['submit']))
    {
        //Get all the values from form to update
        $id = $_POST['id'];
        $name = $_POST['name'];
        $username = $_POST['username'];
		$address = $_POST['address'];
		$email = $_POST['email'];

        //Create a SQL Query to Update User
        $sql = "UPDATE tbl_customer SET
        name = '$name',
        username = '$username',
		address = '$address' ,
		email = '$email' 		
        WHERE id='$id'
        ";

        //Execute the Query
        $res = mysqli_query($conn, $sql);

        //Check whether the query executed successfully or not
        if($res==true)
        {
            //Query Executed and User Updated
            $_SESSION['update'] = "<div class='success'>Admin Updated user.</div>";
            //Redirect to Manage User Page
            header('location:'.SITEURL.'admin/manage-user.php');
        }
        else
        {
            //Failed to Update User
            $_SESSION['update'] = "<div class='error'>Failed to Delete user.</div>";
            //Redirect to Manage User Page
            header('location:'.SITEURL.'admin/manage-user.php');
        }
    }

?>


<?php include('partials/footer.php'); ?>
<!--code end-->

