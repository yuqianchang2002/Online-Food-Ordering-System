<!-- Footer Section Starts -->
<div class="footer">
            <div class="wrapper">
                <p class="text-center"><?php echo date("Y"); ?> All rights reserved. Developed By Group 3 (Chang Yu Qian, Felix Hoi Man Yew, Alda Lim, Jerusha)</a></p>
            </div>
        </div>
        <!-- Footer Section Ends -->

    </body>
</html>
<!--code end-->
